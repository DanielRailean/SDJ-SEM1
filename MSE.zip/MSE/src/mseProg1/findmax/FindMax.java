package mseProg1.findmax;

public class FindMax
{
  public int findMax(int input1, int input2) {
    // TODO implement method
    if(input1>input2) return input1; else return input2;

  }
}
